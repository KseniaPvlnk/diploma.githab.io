import React, { useEffect, useState } from 'react';
import * as eva from '@eva-design/eva';
import { ApplicationProvider, IconRegistry } from '@ui-kitten/components';
import { EvaIconsPack } from '@ui-kitten/eva-icons';
import AppNavigator from './AppNavigator';
import { ThemeContext } from './theme-context';
import AsyncStorage from '@react-native-community/async-storage';

// Imports: Redux Persist Persister
import { PersistGate } from 'redux-persist/integration/react';
import { store, persistor } from './redux/store/store';
import { Provider } from 'react-redux';

export default () => {
  const [theme, setTheme] = useState('dark');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      let storageTheme = await AsyncStorage.getItem('theme');
      if (!storageTheme) {
        await AsyncStorage.setItem('theme', 'light');
        storageTheme = 'light';
      }
      setTheme(storageTheme);
      setLoading(false);
    }
    fetchData();
  });

  const toggleTheme = () => {
    const nextTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(nextTheme);
  };

  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <IconRegistry icons={EvaIconsPack} />
        <ThemeContext.Provider value={{ theme, toggleTheme }}>
          <ApplicationProvider {...eva} theme={eva[theme]}>
            {loading ? null : <AppNavigator />}
          </ApplicationProvider>
        </ThemeContext.Provider>
      </PersistGate>
    </Provider>
  );
};

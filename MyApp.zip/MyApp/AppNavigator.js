import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createStackNavigator } from '@react-navigation/stack';

import Drawer from './components/Drawer';

import SearchByTeacher from './screens/SearchByTeacher';
import ScheduleOfExams from './screens/ScheduleOfExams';
import ScheduleOfMeetings from './screens/ScheduleOfMeetings';
import ScheduleOfEvents from './screens/ScheduleOfEvents';
import ScheduleOfSeminars from './screens/ScheduleOfSeminars';

import TeacherSchedule from './screens/TeacherSchedule';
import Search from './screens/Search';

function SearchByTeacherStack() {
  const Stack = createStackNavigator();
  return (
    <Stack.Navigator headerMode="none">
      <Stack.Screen name="SearchByTeacher" component={SearchByTeacher} />
      <Stack.Screen name="TeacherSchedule" component={TeacherSchedule} />
      <Stack.Screen name="Search" component={Search} />
    </Stack.Navigator>
  );
}

const DrawerNavigator = () => {
  const { Navigator, Screen } = createDrawerNavigator();
  return (
    <Navigator drawerContent={(props) => <Drawer {...props} />}>
      <Screen name="SearchByTeacher" component={SearchByTeacherStack} />
      <Screen name="ScheduleOfExams" component={ScheduleOfExams} />
      <Screen name="ScheduleOfMeetings" component={ScheduleOfMeetings} />
      <Screen name="ScheduleOfEvents" component={ScheduleOfEvents} />
      <Screen name="ScheduleOfSeminars" component={ScheduleOfSeminars} />
    </Navigator>
  );
};

export default () => {
  return (
    <NavigationContainer>
      <DrawerNavigator />
    </NavigationContainer>
  );
};

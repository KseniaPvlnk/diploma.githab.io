import React from 'react';
import {StyleSheet, View} from 'react-native';
import {
  Avatar,
  Icon,
  MenuItem,
  OverflowMenu,
  Text,
  TopNavigation,
  TopNavigationAction,
} from '@ui-kitten/components';
import {useNavigation} from '@react-navigation/native';

const LikeIcon = (props) => <Icon {...props} name="star-outline" />;

const BackIcon = (props) => <Icon {...props} name="arrow-back" />;

export default ({title}) => {
  const navigation = useNavigation();
  const renderLikeAction = () => <TopNavigationAction icon={LikeIcon} />;

  const renderBackAction = () => (
    <TopNavigationAction
      onPress={() => {
        navigation.goBack();
      }}
      icon={BackIcon}
    />
  );
  const renderTitle = (props) => (
    <View style={styles.titleContainer}>
      <Text category="h6" style={styles.title}>
        {title}
      </Text>
    </View>
  );

  return (
    <TopNavigation
      alignment="center"
      title={renderTitle}
      accessoryLeft={renderBackAction}
      // accessoryRight={renderLikeAction}
    />
  );
};

const styles = StyleSheet.create({
  title: {
    textTransform: 'uppercase',
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logo: {
    marginHorizontal: 16,
  },
});

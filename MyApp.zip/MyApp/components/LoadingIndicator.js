import React from 'react';
import {StyleSheet, View} from 'react-native';
import {Layout, Spinner} from '@ui-kitten/components';

export default (props) => (
  <Layout style={styles.container}>
    <View style={[props.style, styles.indicator]}>
      <Spinner size="giant" />
    </View>
  </Layout>
);

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    padding: 20,
  },
  listContainer: {
    paddingHorizontal: 15,
  },
});

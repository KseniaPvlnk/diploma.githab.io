import React from 'react';
import {StyleSheet} from 'react-native';
import {Divider, List, ListItem} from '@ui-kitten/components';

import {localeDays} from './locale';

export default ({data}) => {
  const renderItem = ({item, index}) => {
    const getDescription = () => `${item.time}  ${item.description}`;
    return (
      <ListItem title={localeDays(item.day)} description={getDescription()} />
    );
  };
  console.log(data);
  return (
    <List
      style={styles.container}
      data={data}
      ItemSeparatorComponent={Divider}
      renderItem={renderItem}
    />
  );
};

const styles = StyleSheet.create({
  container: {},
});

export const localeDays = (day) => {
  switch (day) {
    case 'monday':
      return 'Понеділок';
    case 'friday':
      return "П'ятниця";
    case 'thursday':
      return 'Четвер';
    case 'tuesday':
      return 'Вівторок';
    case 'wednesday':
      return 'Середа';
    case 'saturday':
      return 'Субота';
    case 'sunday':
      return 'Неділя';
    default:
      return day;
  }
};

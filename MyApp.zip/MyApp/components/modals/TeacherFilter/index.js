import React, { useRef, useState, useEffect } from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { Layout, Select, Text, useTheme } from '@ui-kitten/components';
import { Modalize } from 'react-native-modalize';

import Form from './Form';

export default function ({ visible = true }) {
  const modalRef = useRef(null);
  const theme = useTheme();
  useEffect(() => {
    if (visible) modalRef.current.open();
  }, [visible]);

  return (
    <Modalize
      modalTopOffset={180}
      ref={modalRef}
      modalStyle={[
        styles.modalStyle,
        { backgroundColor: theme['background-basic-color-1'] },
      ]}>
      <Form modalVisible={visible} />
    </Modalize>
  ); 
}

const styles = StyleSheet.create({
  modalStyle: {
    paddingTop: 40,
  },
  selectStyle: {
    marginBottom: 20,
  },
});

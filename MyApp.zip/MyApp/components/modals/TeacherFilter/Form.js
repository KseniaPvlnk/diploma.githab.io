import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';

import { Layout, RadioGroup, Radio, Text, CheckBox } from '@ui-kitten/components';

export default function Form() {
  const handleTypeChange = (value, name) => {
    if (values[name] === value) {
      setValues({ ...values, [name]: value });
    } else {
      setValues({ ...values, departments: [], [name]: value });
    }
  };

  const handleDepartmentsChange = (value) => {
    const checked = getChecked(value);
    let departments;
    if (checked) {
      departments = values.departments.filter((v) => v !== value);
    } else {
      departments = [...values.departments, value];
    }
    setValues({
      ...values,
      departments,
    });
  };

  const [values, setValues] = useState({ departments: [] });

  const getChecked = (value) => values.departments.includes(value);

  const _renderContent = () => {
    if (values.type === 0) {
      return (
        <Layout style={[styles.container, styles.containerDepartments]}>
          <CheckBox
            style={[styles.checkbox, styles.checkboxDepartmens]}
            status="basic"
            checked={getChecked('1')}
            onChange={() => handleDepartmentsChange('1')}>
            Фортепіанічний
          </CheckBox>
          <CheckBox
            style={[styles.checkbox, styles.checkboxDepartmens]}
            status="basic"
            checked={getChecked('2')}
            onChange={() => handleDepartmentsChange('2')}>
            Народних інструментів (баян, акордеон)
          </CheckBox>
          <CheckBox
            style={[styles.checkbox, styles.checkboxDepartmens]}
            status="basic"
            checked={getChecked('3')}
            onChange={() => handleDepartmentsChange('3')}>
            Народних струнних інструментів (домра, гітара, бандура)
          </CheckBox>
        </Layout>
      );
    } else if (values.type === 1) {
      <Layout></Layout>;
    }
  };

  return (
    <Layout style={styles.mainContainer}>
      <Layout style={styles.header}>
        <Text category="h5">Найдено: 88</Text>
      </Layout>
      <Layout style={styles.formContainer}>
        <Layout style={[styles.container, styles.containerTypeOfLessons]}>
          <RadioGroup
            style={styles.typeOfLessonsRadio}
            selectedIndex={values.type}
            onChange={(index) => handleTypeChange(index, 'type')}>
            <Radio>Індивідуальний</Radio>
            <Radio>Груповий</Radio>
          </RadioGroup>
        </Layout>
        {_renderContent()}
      </Layout>
    </Layout>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 10,
    marginBottom: 15,
  },
  mainContainer: {
    paddingHorizontal: 10,
  },
  formContainer: {
    alignItems: 'center',
  },
  container: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: 10,
  },

  containerTypeOfLessons: {},
  typeOfLessonsRadio: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  containerDepartments: {
    flexDirection: 'column',
    alignItems: 'center',
    paddingHorizontal: 30,
  },
  checkboxDepartmens: {
    width: 300,
    marginBottom: 10,
  },

  checkbox: {
    margin: 2,
  },
  controlContainer: {
    borderRadius: 4,
    margin: 2,
    padding: 6,
    backgroundColor: '#3366FF',
  },
  modalStyle: {
    padding: 20,
    paddingTop: 40,
  },
  selectStyle: {
    marginBottom: 20,
  },
});

import React from 'react';
import { SafeAreaView } from 'react-native'
import { Layout, Button, Text, useTheme } from '@ui-kitten/components';

export default (props) => {
  const theme = useTheme();
  return (
    <SafeAreaView style={{ backgroundColor: theme['background-basic-color-1'] }}>
      <Layout
        style={{ padding: 15, minHeight: 100, justifyContent: 'center' }}
        level="2">
        <Text category="h6">Розклад занять у музичній школі</Text>
      </Layout>
    </SafeAreaView>
  )
}
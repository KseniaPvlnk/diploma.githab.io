import React from 'react'
import { SafeAreaView } from 'react-native'
import { StyleSheet } from 'react-native'
import { Icon, Text, Button, Layout, useTheme } from '@ui-kitten/components'

import AsyncStorage from '@react-native-community/async-storage'

const MoonIcon = (props) => <Icon {...props} name="moon" />
const SunIcon = (props) => <Icon {...props} name="sun" />

export default (toggleTheme, theme) => {
  // const theme = AsyncStorage

  const _renderIcon = () => (theme === 'light' ? MoonIcon : SunIcon)

  const handlePress = async () => {
    const nextTheme = theme === 'light' ? 'dark' : 'light'
    await AsyncStorage.setItem('theme', nextTheme)
    toggleTheme()
  }

  const uheme = useTheme();
  return (
    <SafeAreaView style={{ backgroundColor: uheme['background-basic-color-1'] }}>
      <Layout style={styles.container}>
        <Button
          onPress={handlePress}
          status="basic"
          size="tiny"
          accessoryLeft={_renderIcon()}
        />
      </Layout>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    padding: 15,
    flexDirection: 'row',
  },
})

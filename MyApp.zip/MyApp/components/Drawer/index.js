import React, { useEffect } from 'react'
import { SafeAreaView } from 'react-native'
import { ThemeContext } from '../../theme-context'

import { Icon, Drawer, DrawerItem } from '@ui-kitten/components'

import DrawerFooter from './DrawerFooter'
import DrawerHeader from './DrawerHeader'

const PersoneIcon = (props) => <Icon {...props} name="person-done-outline" />
const PlusIcon = (props) => <Icon {...props} name="plus-circle-outline" />
const QuestionIcon = (props) => (
  <Icon {...props} name="question-mark-circle-outline" />
)
const PlayIcon = (props) => <Icon {...props} name="play-circle-outline" />
const FileIcon = (props) => <Icon {...props} name="file-add-outline" />

export default ({ navigation, state }) => {
  const themeContext = React.useContext(ThemeContext)
  const { theme, toggleTheme } = themeContext

  return (
    <Drawer
      header={DrawerHeader}
      footer={() => DrawerFooter(toggleTheme, theme)}
      selectedIndex={state.index}
      onSelect={(index) => navigation.navigate(state.routeNames[index.row])}>
      <DrawerItem title="Пошук по викладачу" accessoryLeft={PersoneIcon} />
      <DrawerItem
        title="Графік академічних концертів, заліків та іспитів"
        accessoryLeft={PlusIcon}
      />
      <DrawerItem
        title="Графік педрад та засідань ЦК"
        accessoryLeft={QuestionIcon}
      />
      <DrawerItem title="Графік заходів" accessoryLeft={PlayIcon} />
      <DrawerItem title="Розклад семінарів" accessoryLeft={FileIcon} />
    </Drawer>
  )
}

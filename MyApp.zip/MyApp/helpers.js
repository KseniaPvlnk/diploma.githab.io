export const filterTeachersByName = (query, teachers) => {
  if (!query) return teachers;
  return teachers.filter((t) => t.name.includes(query));
};

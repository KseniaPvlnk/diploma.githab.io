import page from '../containers/SearchByTeacher'

export default page
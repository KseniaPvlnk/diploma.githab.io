import React, { useState } from 'react';
import { StyleSheet } from 'react-native';
import {
  Input,
  Text,
  Divider,
  Button,
  Icon,
  Layout,
} from '@ui-kitten/components';
import DefaultLayout from '../layout/Default';
import ListTeachers from '../containers/SearchByTeacher/ListTeachers';

import { connect } from 'react-redux';

import { setSearch } from '../redux/actions/teachersActions';

const SearchIcon = (style) => <Icon {...style} name="search" />;

const BackIcon = (props) => <Icon {...props} name="arrow-back" />;

const Search = () => {
  const [query, setQuery] = useState('');
  return (
    <>
      <Layout style={styles.searchBar}>
        <Input
          defaultValue={query}
          onChangeText={setQuery}
          style={styles.searchBarInput}
          placeholder="Почніть друкувати..."
          icon={SearchIcon}
        />
      </Layout>
      <Divider />
      <DefaultLayout>
        <ListTeachers query={query} />
      </DefaultLayout>
    </>
  );
};

const styles = StyleSheet.create({
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 5,
  },
  searchBarButton: {
    borderRadius: 100,
    marginRight: 10,
  },
  searchBarInput: {
    flex: 1,
    marginTop: 5,
  },
  listContainer: {
    paddingHorizontal: 15,
  },
});

// const mapStateToProps = (state) => {
//   return {
//     query: state.teachers.query,
//   };
// };

// const mapDispatchToProps = (dispatch) => {
//   return {
//     onChange: (query) => {
//       dispatch(setSearch(query));
//     },
//   };
// };

export default connect(null, null)(Search);

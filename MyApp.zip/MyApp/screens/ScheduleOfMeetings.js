import page from '../containers/ScheduleOfMeetings'

export default page
import React from 'react';
import {Layout, Divider, Text} from '@ui-kitten/components';

import DefaultLayout from '../layout/Default';
import TopNavigator from '../components/TeacherScheduleNavigator';
import ScheduleList from '../components/ScheduleList';

export default function ({route}) {
  const data = route.params;
  return (
    <>
      <TopNavigator title={data.name} />
      <Divider />
      <DefaultLayout>
        <ScheduleList data={data.hours} />
      </DefaultLayout>
    </>
  );
}

import page from '../containers/ScheduleOfEvents'

export default page
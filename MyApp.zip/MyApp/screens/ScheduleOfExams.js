import page from '../containers/ScheduleOfExams'

export default page
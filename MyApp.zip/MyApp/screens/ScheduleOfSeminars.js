import page from '../containers/ScheduleOfSeminars'

export default page
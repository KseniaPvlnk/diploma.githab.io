import React, { useEffect } from 'react'
import {
    ScrollView,
    RefreshControl,
    SafeAreaView
} from 'react-native'
import { StyleSheet } from 'react-native'
import {
    Icon,
    Divider,
    TopNavigation,
    TopNavigationAction,
    useTheme
} from '@ui-kitten/components'
import { Tab, TabView } from '@ui-kitten/components'

import ListTeachers from './ListTeachers'
import DefaultLayout from '../../layout/Default'

const SearchIcon = (style) => <Icon {...style} name="search" />

const SearchByTeacher = ({ navigation, onFetchTeachers }) => {
    const [selectedIndex, setSelectedIndex] = React.useState(0)

    const renderSettingsAction = () => (
        <TopNavigationAction
            onPress={() => navigation.navigate('Search')}
            icon={SearchIcon}
        />
    )

    const theme = useTheme();

    return (
        <>
            <SafeAreaView style={{ backgroundColor: theme['background-basic-color-1'] }}>
                <TopNavigation
                    title="Пошук по викладачу"
                    alignment="center"
                    accessoryRight={renderSettingsAction}
                />
                <Divider />
            </SafeAreaView>
            <DefaultLayout>
                <TabView
                    selectedIndex={selectedIndex}
                    onSelect={setSelectedIndex}>
                    <Tab title='Індивідуальний'>
                        <ListTeachers departmentsType={1} />
                    </Tab>
                    <Tab title='Груповий'>
                        <ListTeachers departmentsType={2} />
                    </Tab>
                </TabView>
            </DefaultLayout>
        </>
    )
}

const styles = StyleSheet.create({})

export default SearchByTeacher

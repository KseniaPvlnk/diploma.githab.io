import React, { useEffect } from 'react'
import { RefreshControl } from 'react-native'
import { Layout, List, Divider, ListItem } from '@ui-kitten/components'
import { useNavigation } from '@react-navigation/native'
import { connect } from 'react-redux'
import { fetchTeachers } from '../../redux/actions/teachersActions'

import { filterTeachersByName } from '../../helpers'

const ListTeachers = ({ departmentsType = null, teachers, query, onFetchTeachers }) => {

  const navigation = useNavigation()
  const getDescription = (item) =>
    item.departments.map((i) => i.name).join(', ')

  const renderItem = ({ item, index }) => (
    <ListItem
      onPress={() => navigation.navigate('TeacherSchedule', item)}
      title={item.name}
      description={getDescription(item)}
    />
  )

  const fetchData = () => onFetchTeachers()

  useEffect(() => {
    fetchData()
  }, [])

  let filteredData = []
  if (query) {
    filteredData = filterTeachersByName(query, teachers)
  } else if (departmentsType) {
    filteredData = teachers.filter(t => {
      for (let dep of t.departments) {
        if (dep.type_of_class === departmentsType)
          return true
      }
    })
  } else {
    filteredData = teachers
  }

  return (
    <Layout style={{ minHeight: '100%' }}>
      <List
        data={filteredData}
        renderItem={renderItem}
        ItemSeparatorComponent={Divider}
        refreshControl={
          <RefreshControl refreshing={false} onRefresh={fetchData} />
        }
      />
    </Layout>
  )
}

const mapStateToProps = (state) => {
  return {
    teachers: state.teachers.data,
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    onFetchTeachers: () => {
      dispatch(fetchTeachers())
    },
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(ListTeachers)

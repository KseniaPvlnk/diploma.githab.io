import React, { useEffect } from 'react'
import { ScrollView, RefreshControl } from 'react-native'
import { connect } from 'react-redux'

import DefaultLayout from '../../layout/Default'
import TopNavigator from '../../components/TopNavigation'

import { useNavigation } from '@react-navigation/native'

import { SeminarsList } from './SeminarsList'

import { fetchSeminars } from '../../redux/actions/seminarsActions'

const ScheduleOfExams = ({ data, onFetchSeminars }) => {
    const navigation = useNavigation()

    useEffect(() => {
        onFetchSeminars()
    }, [])


    return (
        <ScrollView contentContainerStyle={{ minHeight: '100%' }} refreshControl={
            <RefreshControl refreshing={false} onRefresh={onFetchSeminars} />
        }>
            <TopNavigator title="Розклад семінарів" />
            <DefaultLayout>
                <SeminarsList data={data} />
            </DefaultLayout>
        </ScrollView>
    )
}

const mapStateToProps = (state) => {
    return {
        data: state.seminars.data
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        onFetchSeminars: () => {
            dispatch(fetchSeminars())
        },
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(ScheduleOfExams)




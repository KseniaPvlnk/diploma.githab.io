import React, { useEffect } from 'react'
import {
    ScrollView,
    RefreshControl
} from 'react-native'
import { connect } from 'react-redux'

import { Tab, TabView } from '@ui-kitten/components'

import DefaultLayout from '../../layout/Default'
import TopNavigator from '../../components/TopNavigation'

import { useNavigation } from '@react-navigation/native'

import { ExamsList } from './ExamsList'

import { fetchExams } from '../../redux/actions/examsActions'

const ScheduleOfExams = ({ data, onFetchExams }) => {
    const navigation = useNavigation()
    const [selectedIndex, setSelectedIndex] = React.useState(0)

    useEffect(() => {
        onFetchExams()
    }, [])

    return (
        <ScrollView contentContainerStyle={{ minHeight: '100%' }} refreshControl={
            <RefreshControl refreshing={false} onRefresh={onFetchExams} />
        }>
            <TopNavigator title="Графік академічних концертів, заліків та іспитів" />
            <DefaultLayout>

                <TabView
                    selectedIndex={selectedIndex}
                    onSelect={setSelectedIndex}>
                    <Tab title='6-річний'>
                        <ExamsList data={data} year={6} />
                    </Tab>
                    <Tab title='8-річний'>
                        <ExamsList data={data} year={8} />
                    </Tab>
                </TabView>
            </DefaultLayout>
        </ScrollView >
    )
}

const mapStateToProps = (state) => {
    return {
        data: state.exams.data
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        onFetchExams: () => {
            dispatch(fetchExams());
        },
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(ScheduleOfExams);
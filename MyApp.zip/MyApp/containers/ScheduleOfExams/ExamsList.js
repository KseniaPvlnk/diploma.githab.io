import React from 'react'
import { StyleSheet } from 'react-native'
import { RefreshControl } from 'react-native'
import { Layout, Text } from '@ui-kitten/components'
import { List, Divider, ListItem } from '@ui-kitten/components'

import moment from 'moment'

export const ExamsList = ({ data, year }) => {
    const renderItem = ({ item, index }) => (
        <ListItem
            title={moment(item.date).format("DD.MM HH:mm")}
            description={item.description}
        />
    )

    const filtered = data.filter(d => d.year === year)

    return (
        <Layout style={{ minHeight: '100%' }}>
            <List
                data={filtered}
                renderItem={renderItem}
                ItemSeparatorComponent={Divider}
            />
        </Layout>
    )
}

import React from 'react'
import { StyleSheet } from 'react-native'
import { RefreshControl } from 'react-native'
import { Layout, Text } from '@ui-kitten/components'
import { List, Divider, ListItem } from '@ui-kitten/components'

import moment from 'moment'

export const MeetingsList = ({ data }) => {
    const renderItem = ({ item, index }) => (
        <ListItem
            title={moment(item.date).format("DD.MM - HH:mm")}
            description={item.description}
        />
    )

    return (
        <Layout style={{ minHeight: '100%' }}>
            <List
                data={data}
                renderItem={renderItem}
                ItemSeparatorComponent={Divider}
            />
        </Layout>
    )
}

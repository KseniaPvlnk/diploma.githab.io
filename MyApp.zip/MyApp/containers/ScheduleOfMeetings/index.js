import React, { useEffect } from 'react'
import {
    ScrollView,
    RefreshControl
} from 'react-native'
import { connect } from 'react-redux'

import DefaultLayout from '../../layout/Default'
import TopNavigator from '../../components/TopNavigation'

import { useNavigation } from '@react-navigation/native'

import { MeetingsList } from './MeetingsList'

import { fetchMeetings } from '../../redux/actions/meetingsActions'

const ScheduleOfExams = ({ data, onFetchMeetings }) => {
    const navigation = useNavigation()

    useEffect(() => {
        onFetchMeetings()
    }, [])


    return (
        <ScrollView contentContainerStyle={{ minHeight: '100%' }} refreshControl={
            <RefreshControl refreshing={false} onRefresh={onFetchMeetings} />
        }>
            <TopNavigator title="Графік педрад та засідань ЦК" />
            <DefaultLayout>
                <MeetingsList data={data} />
            </DefaultLayout>
        </ScrollView>
    )
}

const mapStateToProps = (state) => {
    return {
        data: state.meetings.data
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        onFetchMeetings: () => {
            dispatch(fetchMeetings())
        },
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(ScheduleOfExams)
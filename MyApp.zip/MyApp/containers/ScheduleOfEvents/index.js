import React, { useEffect } from 'react'
import { ScrollView, RefreshControl } from 'react-native'
import { connect } from 'react-redux'

import DefaultLayout from '../../layout/Default'
import TopNavigator from '../../components/TopNavigation'

import { useNavigation } from '@react-navigation/native'

import { EventsList } from './EventsList'

import { fetchEvents } from '../../redux/actions/eventsActions'
import { SafeAreaView } from 'react-native-safe-area-context'

const ScheduleOfExams = ({ data, onFetchEvents }) => {
    const navigation = useNavigation()

    useEffect(() => {
        onFetchEvents()
    }, [])


    return (
        <ScrollView contentContainerStyle={{ minHeight: '100%' }} refreshControl={
            <RefreshControl refreshing={false} onRefresh={onFetchEvents} />
        }>
            <TopNavigator title="Графік заходів" />
            <DefaultLayout>
                <EventsList data={data} />
            </DefaultLayout>
        </ScrollView>
    )
}

const mapStateToProps = (state) => {
    return {
        data: state.events.data
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        onFetchEvents: () => {
            dispatch(fetchEvents())
        },
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(ScheduleOfExams)




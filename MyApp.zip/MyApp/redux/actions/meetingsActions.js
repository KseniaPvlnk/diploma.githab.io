import axios from 'axios';

import {
    FETCH_MEETINGS_SUCCESS,
    FETCH_MEETINGS_FAILURE,
    FETCH_MEETINGS_STARTED,
} from '../types';

import { API } from '../api'
export const fetchMeetings = () => {
    return (dispatch) => {
        dispatch(fetchExamsStarted());

        API
            .get('/schedule-of-meetings')
            .then((res) => {
                dispatch(fetchExamsSuccess(res.data));
            })
            .catch((err) => {
                dispatch(fetchExamsFailure(err.message));
            });
    };
};

const fetchExamsSuccess = (meetings) => ({
    type: FETCH_MEETINGS_SUCCESS,
    payload: meetings,
});

const fetchExamsStarted = () => ({
    type: FETCH_MEETINGS_STARTED,
});

const fetchExamsFailure = (error) => ({
    type: FETCH_MEETINGS_FAILURE,
    payload: error
});

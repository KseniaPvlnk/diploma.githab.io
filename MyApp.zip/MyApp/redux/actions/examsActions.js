import axios from 'axios';

import {
    FETCH_EXAMS_SUCCESS,
    FETCH_EXAMS_FAILURE,
    FETCH_EXAMS_STARTED,
} from '../types';

import { API } from '../api'
export const fetchExams = () => {
    return (dispatch) => {
        dispatch(fetchExamsStarted());

        API
            .get('/schedule-of-exams')
            .then((res) => {
                dispatch(fetchExamsSuccess(res.data));
            })
            .catch((err) => {
                dispatch(fetchExamsFailure(err.message));
            });
    };
};

const fetchExamsSuccess = (exams) => ({
    type: FETCH_EXAMS_SUCCESS,
    payload: exams,
});

const fetchExamsStarted = () => ({
    type: FETCH_EXAMS_STARTED,
});

const fetchExamsFailure = (error) => ({
    type: FETCH_EXAMS_FAILURE,
    payload: error
});

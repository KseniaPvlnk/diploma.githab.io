import axios from 'axios'

import {
    FETCH_EVENTS_SUCCESS,
    FETCH_EVENTS_FAILURE,
    FETCH_EVENTS_STARTED,
} from '../types'

import { API } from '../api'

export const fetchEvents = () => {
    return (dispatch) => {
        dispatch(fetchEventsStarted())

        API
            .get('/schedule-of-events')
            .then((res) => {
                dispatch(fetchEventsSuccess(res.data))
            })
            .catch((err) => {
                dispatch(fetchEventsFailure(err.message))
            })
    }
}

const fetchEventsSuccess = (Events) => ({
    type: FETCH_EVENTS_SUCCESS,
    payload: Events,
})

const fetchEventsStarted = () => ({
    type: FETCH_EVENTS_STARTED,
})

const fetchEventsFailure = (error) => ({
    type: FETCH_EVENTS_FAILURE,
    payload: error
})

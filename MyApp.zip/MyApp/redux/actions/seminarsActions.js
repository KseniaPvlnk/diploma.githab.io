import axios from 'axios'

import {
    FETCH_SEMINARS_SUCCESS,
    FETCH_SEMINARS_FAILURE,
    FETCH_SEMINARS_STARTED,
} from '../types'

import { API } from '../api'
export const fetchSeminars = () => {
    return (dispatch) => {
        dispatch(fetchSeminarsStarted())

        API
            .get('/schedule-of-seminars')
            .then((res) => {
                dispatch(fetchSeminarsSuccess(res.data))
            })
            .catch((err) => {
                dispatch(fetchSeminarsFailure(err.message))
            })
    }
}

const fetchSeminarsSuccess = (seminars) => ({
    type: FETCH_SEMINARS_SUCCESS,
    payload: seminars,
})

const fetchSeminarsStarted = () => ({
    type: FETCH_SEMINARS_STARTED,
})

const fetchSeminarsFailure = (error) => ({
    type: FETCH_SEMINARS_FAILURE,
    payload: error
})

import axios from 'axios';

import {
  FETCH_TEACHERS_SUCCESS,
  FETCH_TEACHERS_FAILURE,
  FETCH_TEACHERS_STARTED,
  SEARCH_TEACHERS_BY_NAME,
} from '../types';

import { API } from '../api'
export const fetchTeachers = () => {
  return (dispatch) => {
    dispatch(fetchTeachersStarted());

    API
      .get('/teachers')
      .then((res) => {
        dispatch(fetchTeachersSuccess(res.data));
      })
      .catch((err) => {
        dispatch(fetchTeachersFailure(err.message));
      });
  };
};

const fetchTeachersSuccess = (teachers) => ({
  type: FETCH_TEACHERS_SUCCESS,
  payload: teachers,
});

const fetchTeachersStarted = () => ({
  type: FETCH_TEACHERS_STARTED,
});

const fetchTeachersFailure = (error) => ({
  type: FETCH_TEACHERS_FAILURE,
  payload: {
    error,
  },
});

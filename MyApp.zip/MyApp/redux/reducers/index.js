// Imports: Dependencies
import { combineReducers } from 'redux';

// Imports: Reducers
import teachersReducer from './teachersReducer';
import examsReducer from './examsReducer'
import meetingsReducer from './meetingsReducer'
import eventsReducer from './eventsReducer'
import seminarsReducer from './seminarsReducer'

// Redux: Root Reducer
const rootReducer = combineReducers({
  teachers: teachersReducer,
  exams: examsReducer,
  meetings: meetingsReducer,
  events: eventsReducer,
  seminars: seminarsReducer
});

// Exports
export default rootReducer;

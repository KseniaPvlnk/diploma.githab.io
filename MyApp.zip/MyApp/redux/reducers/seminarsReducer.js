import {
    FETCH_SEMINARS_SUCCESS,
    FETCH_SEMINARS_FAILURE,
    FETCH_SEMINARS_STARTED,
} from '../types';

// Initial State
const initialState = {
    data: [],
};

// Reducers (Modifies The State And Returns A New State)
export default function seminarsReducer(state = initialState, action) {
    switch (action.type) {
        case FETCH_SEMINARS_SUCCESS: {
            return {
                ...state,
                data: action.payload,
                fetching: false
            };
        }
        case FETCH_SEMINARS_STARTED: {
            return {
                ...state,
                fetching: true
            }
        }
        case FETCH_SEMINARS_FAILURE: {
            return {
                ...state,
                fetching: false,
                error: actions.payload
            }
        }
        default: {
            return state;
        }
    }
}

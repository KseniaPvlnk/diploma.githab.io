import {
    FETCH_EVENTS_SUCCESS,
    FETCH_EVENTS_FAILURE,
    FETCH_EVENTS_STARTED,
} from '../types';

// Initial State
const initialState = {
    data: [],
};

// Reducers (Modifies The State And Returns A New State)
export default function eventsReducer(state = initialState, action) {
    switch (action.type) {
        case FETCH_EVENTS_SUCCESS: {
            return {
                ...state,
                data: action.payload,
                fetching: false
            };
        }
        case FETCH_EVENTS_STARTED: {
            return {
                ...state,
                fetching: true
            }
        }
        case FETCH_EVENTS_FAILURE: {
            return {
                ...state,
                fetching: false,
                error: actions.payload
            }
        }
        default: {
            return state;
        }
    }
}

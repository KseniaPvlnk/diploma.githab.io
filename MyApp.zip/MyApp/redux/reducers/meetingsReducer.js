import {
    FETCH_MEETINGS_SUCCESS,
    FETCH_MEETINGS_FAILURE,
    FETCH_MEETINGS_STARTED,
} from '../types';

// Initial State
const initialState = {
    data: [],
};

// Reducers (Modifies The State And Returns A New State)
export default function examsReducer(state = initialState, action) {
    switch (action.type) {
        case FETCH_MEETINGS_SUCCESS: {
            return {
                ...state,
                data: action.payload,
                fetching: false
            };
        }
        case FETCH_MEETINGS_STARTED: {
            return {
                ...state,
                fetching: true
            }
        }
        case FETCH_MEETINGS_FAILURE: {
            return {
                ...state,
                fetching: false,
                error: actions.payload
            }
        }
        default: {
            return state;
        }
    }
}

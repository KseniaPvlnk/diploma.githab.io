// Initial State
const initialState = {
  data: [],
  // query: '',
};

// Reducers (Modifies The State And Returns A New State)
export default function teachersReducer(state = initialState, action) {
  switch (action.type) {
    case 'FETCH_TEACHERS_SUCCESS': {
      return {
        ...state,
        data: action.payload,
      };
    }
    case 'SEARCH_TEACHERS_BY_NAME': {
      return {
        ...state,
        query: action.payload,
      };
    }
    default: {
      return state;
    }
  }
}
